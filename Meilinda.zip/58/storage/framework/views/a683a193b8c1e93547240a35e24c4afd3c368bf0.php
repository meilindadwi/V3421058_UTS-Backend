<?php $__env->startSection('content'); ?>
<div class="register-box">
    <div class="card card-outline card-primary">
      <div class="card-header text-center">
        <a href="/" class="h1"><b>Admin</b>LTE</a>
      </div>
      <div class="card-body">
        <p class="login-box-msg">Register a new membership</p>

        <form action="/updatePasswordProses64/<?php echo e(Auth::user()->id); ?>" method="post">
            <?php echo csrf_field(); ?>
          <div class="input-group mb-3">
            <input type="password" class="form-control" placeholder="Password baru" name="password">
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-lock"></span>
              </div>
            </div>
          </div>
            <div class="col">
              <button type="submit" class="btn btn-primary">Update password</button>
            </div>
            <!-- /.col -->
          </div>
        </form>
          <a href="/profile64" class="btn btn-block btn-danger mb-2">
            Kembali
          </a>
        </div>
      </div>
      <!-- /.form-box -->
    </div><!-- /.card -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLte_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\S3\PROJECT S3\Backend\tib\resources\views/user/updatePassword.blade.php ENDPATH**/ ?>