<?php $__env->startSection('content'); ?>

<section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Agama</h1>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>


<section class="content">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-6">
              <div class="card">
                <div class="card-header">
                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <h5><i class="icon fas fa-check"></i> Success</h5>
                       <?php echo e($message); ?>

                      </div>
                    <?php endif; ?>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th style="width: 10px">#</th>
                        <th>Agama</th>
                        <th style="width: 12rem">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $agamas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($agama->nama_agama); ?></td>
                            <td>
                                <a href="/updateAgama64/<?php echo e($agama->id); ?>" class="btn btn-primary">Update</a>
                                <a href="/deleteAgama64Proses/<?php echo e($agama->id); ?>" class="btn btn-danger">Delete</a>
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                  <a href="/createAgama64" class="btn btn-primary mt-3">Tambah</a>
                </div>
              </div>
            </div>
          </div>

    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\S3\PROJECT S3\Backend\tib\resources\views/agama/agama.blade.php ENDPATH**/ ?>