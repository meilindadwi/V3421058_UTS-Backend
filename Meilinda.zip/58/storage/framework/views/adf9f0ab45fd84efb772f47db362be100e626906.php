<?php $__env->startSection('content'); ?>

<section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Detail Users</h1>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>


<section class="content">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header">
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <table class="table table-bordered">
                      <tr class="text-center">
                        <th colspan="2"><img src="/img/<?php echo e(Auth::user()->foto); ?>" alt="error" width="200px" class="rounded-circle"></th>
                      </tr>
                      <tr>
                        <th style="width: 50%">Nama lengkap</th>
                        <td style="width: 50%"><?php echo e(Auth::user()->name); ?></td>
                      </tr>
                      <tr>
                        <th>Email</th>
                        <td><?php echo e(Auth::user()->email); ?></td>
                      </tr>
                    </thead>
                </table>
                <div class="row">
                    <div class="col mt-2">
                        <a href="/updatePassword64" class="btn btn-primary">Update password</a>
                        <?php if(Auth::user()->detail_data == null): ?>
                            <?php if(Auth::user()->is_aktif): ?>
                            <a href="/createData64" class="btn btn-primary ">Lengkapi data</a>
                            <?php else: ?>
                            <a href="/createData64" class="btn btn-primary disabled">Lengkapi data</a>
                            <i>Menunggu persetujuan</i>
                            <?php endif; ?>
                        <?php else: ?>
                        <a href="/detailData64" class="btn btn-primary">Detail data</a>
                        <?php endif; ?>
                    </div>
                </div>
                </div>
              </div>
            </div>
          </div>

    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\S3\PROJECT S3\Backend\tib\resources\views/user/profile.blade.php ENDPATH**/ ?>