<?php $__env->startSection('content'); ?>
<div class="register-box">
    <div class="card card-outline card-primary">
      <div class="card-header text-center">
        <a href="/" class="h1"><b>Admin</b>LTE</a>
      </div>
      <div class="card-body">
        <p class="login-box-msg">Update</p>

        <form action="/updateDataProses64" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
          <div class="input-group mb-3">
            <input type="text" class="form-control" value="<?php echo e(Auth::user()->name); ?>" disabled>
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-user"></span>
              </div>
            </div>
          </div>
          <div class="input-group mb-3">
            <input type="text" class="form-control" value="<?php echo e(Auth::user()->email); ?>" disabled>
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-user"></span>
              </div>
            </div>
          </div>
          <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="Alamat" name="alamat" required value="<?php echo e(Auth::user()->detail_data->alamat); ?>">
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-user"></span>
              </div>
            </div>
          </div>
          <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="Tempat lahir" name="tempat_lahir" required value="<?php echo e(Auth::user()->detail_data->tempat_lahir); ?>">
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-envelope"></span>
              </div>
            </div>
          </div>
          <div class="input-group mb-3">
            <input type="date" class="form-control" placeholder="Tanggal lahir" name="tanggal_lahir" required value="<?php echo e(Auth::user()->detail_data->tanggal_lahir); ?>">
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-lock"></span>
              </div>
            </div>
          </div>
          <div class="input-group mb-3">
              <select class="form-control" name="id_agama" required>
                <option selected disabled>Pilih agama</option>
                <?php $__currentLoopData = $agamas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($agama->id); ?>"><?php echo e($agama->nama_agama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          <div class="input-group mb-3">
            <input type="number" class="form-control" placeholder="Umur" name="umur" required value="<?php echo e(Auth::user()->detail_data->umur); ?>">
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-lock"></span>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-8">
              <div class="icheck-primary">
                <input type="checkbox" id="agreeTerms" name="terms" value="agree">
                <label for="agreeTerms">
                 I agree to the <a href="#">terms</a>
                </label>
              </div>
            </div>
            <!-- /.col -->
            <div class="col-4">
              <button type="submit" class="btn btn-primary btn-block">Update</button>
            </div>
            <!-- /.col -->
          </div>
        </form>

        <div class="social-auth-links text-center">
          <a href="/" class="btn btn-block btn-danger">
            Kembali
          </a>
        </div>
      </div>
      <!-- /.form-box -->
    </div><!-- /.card -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLte_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\S3\PROJECT S3\Backend\tib\resources\views/user/updateData.blade.php ENDPATH**/ ?>