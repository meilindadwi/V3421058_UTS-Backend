<?php $__env->startSection('content'); ?>

<section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Detail Users</h1>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>


<section class="content">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header">
                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <h5><i class="icon fas fa-check"></i> Success</h5>
                       <?php echo e($message); ?>

                      </div>
                    <?php endif; ?></h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <table class="table table-bordered">
                      <tr class="text-center">
                        <th colspan="2"><img src="/img/<?php echo e(Auth::user()->foto); ?>" alt="error" width="200px" class="rounded-circle"></th>
                      </tr>
                      <tr>
                        <th style="width: 50%">Nama lengkap</th>
                        <td style="width: 50%"><?php echo e(Auth::user()->name); ?></td>
                      </tr>
                      <tr>
                        <th>Email</th>
                        <td><?php echo e(Auth::user()->email); ?></td>
                      </tr>
                      <tr>
                        <th>Alamat</th>
                        <td><?php echo e(Auth::user()->detail_data->alamat); ?></td>
                      </tr>
                      <tr>
                        <th>Tempat</th>
                        <td><?php echo e(Auth::user()->detail_data->tempat_lahir); ?></td>
                      </tr>
                      <tr>
                        <th>Tanggal</th>
                        <td><?php echo e(Auth::user()->detail_data->tanggal_lahir); ?></td>
                    </tr>
                    <tr>
                      <th>Agama</th>
                      <td><?php echo e(Auth::user()->detail_data->agama->nama_agama); ?></td>
                    </tr>
                    <tr>
                      <th>Umur</th>
                      <td><?php echo e(Auth::user()->detail_data->umur); ?></td>
                    </tr>
                      <tr>
                        <th>Foto KTP</th>
                        <td><?php echo e(Auth::user()->detail_data->foto_ktp); ?></td>
                      </tr>
                    </thead>
                </table>
                <div class="row">
                    <div class="col mt-2">
                        <a href="/updateData64" class="btn btn-primary">Update data</a>
                    </div>
                </div>
                </div>
              </div>
            </div>
          </div>

    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\S3\PROJECT S3\Backend\tib\resources\views/user/detailData.blade.php ENDPATH**/ ?>