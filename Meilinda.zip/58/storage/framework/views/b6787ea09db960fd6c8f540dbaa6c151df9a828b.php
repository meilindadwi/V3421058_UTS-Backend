<?php $__env->startSection('content'); ?>

<section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Users</h1>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>


<section class="content">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Bordered Table</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <table class="table table-bordered">
                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <h5><i class="icon fas fa-check"></i> Success</h5>
                       <?php echo e($message); ?>

                      </div>
                    <?php endif; ?>
                    <thead>
                      <tr>
                        <th style="width: 10px">#</th>
                        <th>Foto</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th style="width: 8rem">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($user->foto); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php if($user->is_aktif): ?>
                                <a href="/detailUser64/<?php echo e($user->id); ?>" class="btn btn-primary">Detail</a>
                                <?php else: ?>
                                <a href="/approveUser64/<?php echo e($user->id); ?>" class="btn btn-danger">Approve</a>
                                <?php endif; ?>
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\S3\PROJECT S3\Backend\tib\resources\views/user/users.blade.php ENDPATH**/ ?>