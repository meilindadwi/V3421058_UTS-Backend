<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Agama58Controller;
use App\Http\Controllers\User58Controller;
use App\Http\Controllers\Detail_data58Controller;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {

    if (Auth::check()) {
        $role = Auth::user()->role;
    } else {
        $role = null;
    }

    return view('dashboard', [
        'role'=>$role
    ]);
})->name('index58');

Route::middleware(['auth', 'hakakses:role'])->group(function () {

    // User
    Route::get('/users58', [User58Controller::class, 'users58'])->name('users58');
    Route::get('/detailUser58/{id}', [User58Controller::class, 'detailUser58'])->name('detailUser58');
    Route::get('/profile58', [User58Controller::class, 'profile58'])->name('profile58');


    Route::get('/updatePassword58', [User58Controller::class, 'updatePassword58'])->name('updatePassword58');
    Route::post('/updatePasswordProses58/{id}', [User58Controller::class, 'updatePasswordProses58'])->name('updatePasswordProses58');

    Route::get('/logout58', [User58Controller::class, 'logout58'])->name('logout58');

    // Detail data
    Route::get('/detailData58', [Detail_data58Controller::class, 'detailData58'])->name('detailData58');

    Route::get('/createData58', [Detail_data58Controller::class, 'createData58'])->name('createData58');
    Route::post('/createDataProses58', [Detail_data58Controller::class, 'createDataProses58'])->name('createDataProses58');

    Route::get('/updateData58', [Detail_data58Controller::class, 'updateData58'])->name('updateData58');
    Route::post('/updateDataProses58', [Detail_data58Controller::class, 'updateDataProses58'])->name('updateDataProses58');
});

Route::middleware(['auth', 'hakadmin:role'])->group(function () {
    // agama
    Route::get('/agama58', [Agama58Controller::class, 'agama58'])->name('agama58');

    Route::get('/createAgama58', [Agama58Controller::class, 'createAgama58'])->name('createAgama58');
    Route::post('/createAgama58Proses', [Agama58Controller::class, 'createAgama58Proses'])->name('createAgama58Proses');

    Route::get('/deleteAgama58Proses/{id}', [Agama58Controller::class, 'deleteAgama58Proses'])->name('deleteAgama58Proses');

    Route::get('/updateAgama58/{id}', [Agama58Controller::class, 'updateAgama58'])->name('updateAgama58');
    Route::post('/updateAgama58Proses/{id}', [Agama58Controller::class, 'updateAgama58Proses'])->name('updateAgama58Proses');

    // user
    Route::get('/deleteUser58/{id}', [User58Controller::class, 'deleteUser58'])->name('deleteUser58');
    Route::get('/approveUser58/{id}', [User58Controller::class, 'approveUser58'])->name('approveUser58');
});

Route::get('/login58', [User58Controller::class, 'login58'])->name('login58');
Route::post('/loginProses58', [User58Controller::class, 'loginProses58'])->name('loginProses58');

Route::get('/register58', [User58Controller::class, 'register58'])->name('register58');
Route::post('/registerProses58', [User58Controller::class, 'registerProses58'])->name('registerProses58');


